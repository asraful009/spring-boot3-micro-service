package com.cyber009.sb3m.organization;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrganizationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
